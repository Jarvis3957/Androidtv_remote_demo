// Android TV Remote - Frontend Controller
document.addEventListener('DOMContentLoaded', () => {
  // State
  let activeTab = 'tab-remote';
  let isConnected = false;
  let autoRefreshTimer = null;
  let statusPollTimer = null;
  let serverInfo = null;

  // DOM Elements
  const statusBadge = document.getElementById('btn-status-badge');
  const statusText = document.getElementById('status-text');
  const deviceModelLabel = document.getElementById('device-model-label');
  const footerIpLabel = document.getElementById('footer-ip-label');

  // Modals
  const modalConnect = document.getElementById('modal-connect');
  const modalQr = document.getElementById('modal-qr');
  const btnConnectModal = document.getElementById('btn-connect-modal');
  const btnQrModal = document.getElementById('btn-qr-modal');
  const closeConnectModal = document.getElementById('close-connect-modal');
  const closeQrModal = document.getElementById('close-qr-modal');
  
  // Connection inputs
  const inputTvIp = document.getElementById('input-tv-ip');
  const inputTvPort = document.getElementById('input-tv-port');
  const btnDoConnect = document.getElementById('btn-do-connect');
  const btnDoDisconnect = document.getElementById('btn-do-disconnect');
  const devicesList = document.getElementById('devices-list');
  const mobileUrlDisplay = document.getElementById('mobile-url-display');

  // Keyboard shortcut toggle
  const chkKeyboardListener = document.getElementById('chk-keyboard-listener');

  // Haptic feedback helper
  function triggerHaptic() {
    if ('vibrate' in navigator) {
      try { navigator.vibrate(20); } catch (e) {}
    }
  }

  // Toast Notification
  function showToast(message, type = 'info', duration = 3000) {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    let icon = 'circle-info';
    if (type === 'success') icon = 'circle-check';
    if (type === 'error') icon = 'circle-exclamation';
    
    toast.innerHTML = `<i class="fa-solid fa-${icon}"></i> <span>${message}</span>`;
    container.appendChild(toast);
    
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(8px)';
      toast.style.transition = 'all 0.2s';
      setTimeout(() => toast.remove(), 200);
    }, duration);
  }

  // API Call helper
  async function apiCall(endpoint, method = 'POST', data = null) {
    try {
      const opts = {
        method,
        headers: { 'Content-Type': 'application/json' }
      };
      if (data && method !== 'GET') opts.body = JSON.stringify(data);
      const res = await fetch(endpoint, opts);
      const json = await res.json();
      return json;
    } catch (err) {
      console.error(`API Call failed to ${endpoint}:`, err);
      return { success: false, message: err.message };
    }
  }

  // Send Keyevent
  async function sendKey(keyCode, buttonEl = null) {
    triggerHaptic();
    if (buttonEl) {
      buttonEl.classList.add('pressed');
      setTimeout(() => buttonEl.classList.remove('pressed'), 120);
    }
    const res = await apiCall('/api/keyevent', 'POST', { key: keyCode });
    if (!res.success && res.message) {
      showToast(res.message, 'error', 2000);
    }
  }

  // Fetch Status
  async function fetchStatus() {
    try {
      const res = await fetch('/api/status');
      const data = await res.json();
      serverInfo = data;
      
      // Update IP inputs if not focused
      if (document.activeElement !== inputTvIp && data.last_ip) {
        inputTvIp.value = data.last_ip;
      }
      if (document.activeElement !== inputTvPort && data.last_port) {
        inputTvPort.value = data.last_port;
      }

      // Update badge
      statusBadge.className = `status-badge ${data.status}`;
      if (data.status === 'connected') {
        isConnected = true;
        statusText.textContent = data.active_device || 'Connected';
        deviceModelLabel.textContent = data.device_model || data.active_device || 'Android TV';
        footerIpLabel.textContent = `Connected: ${data.active_device}`;
      } else if (data.status === 'unauthorized') {
        isConnected = false;
        statusText.textContent = 'Auth Needed';
        deviceModelLabel.textContent = 'Check TV screen to accept prompt!';
        footerIpLabel.textContent = 'Authorization required on TV screen';
      } else {
        isConnected = false;
        statusText.textContent = 'Disconnected';
        deviceModelLabel.textContent = 'No TV connected';
        footerIpLabel.textContent = `Server: ${data.server_url}`;
      }

      mobileUrlDisplay.textContent = data.server_url;

      // Update connected devices modal list
      renderDevicesList(data.devices, data.active_device);
    } catch (err) {
      statusBadge.className = 'status-badge disconnected';
      statusText.textContent = 'Offline';
    }
  }

  function renderDevicesList(devices, activeId) {
    if (!devices || devices.length === 0) {
      devicesList.innerHTML = '<div class="device-item-placeholder">No devices connected</div>';
      return;
    }
    devicesList.innerHTML = '';
    devices.forEach(dev => {
      const item = document.createElement('div');
      item.className = `device-item ${dev.id === activeId ? 'active' : ''}`;
      item.innerHTML = `
        <div class="device-item-info">
          <span class="device-item-id">${dev.id}</span>
          <span class="device-item-state">${dev.state.toUpperCase()} ${dev.id === activeId ? '• ACTIVE' : ''}</span>
        </div>
        ${dev.id !== activeId ? `<button class="secondary-btn btn-make-active" data-id="${dev.id}">Use</button>` : '<i class="fa-solid fa-check" style="color: var(--accent-green)"></i>'}
      `;
      devicesList.appendChild(item);
    });

    devicesList.querySelectorAll('.btn-make-active').forEach(b => {
      b.addEventListener('click', async (e) => {
        const id = e.currentTarget.getAttribute('data-id');
        await apiCall('/api/set_active', 'POST', { device: id });
        fetchStatus();
      });
    });
  }

  // Periodic polling every 5s
  fetchStatus();
  statusPollTimer = setInterval(fetchStatus, 5000);

  // Tab Navigation
  document.querySelectorAll('.nav-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      triggerHaptic();
      const targetTab = tab.getAttribute('data-tab');
      document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      
      tab.classList.add('active');
      const targetContent = document.getElementById(targetTab);
      if (targetContent) targetContent.classList.add('active');
      activeTab = targetTab;

      // Auto take screenshot if opening screen tab
      if (targetTab === 'tab-screen') {
        const img = document.getElementById('tv-screenshot-img');
        if (img.classList.contains('hidden')) {
          takeScreenshot();
        }
      }
    });
  });

  // Remote Button Event Listeners
  document.querySelectorAll('.remote-btn[data-key], .dpad-btn[data-key], .dpad-center[data-key], .key-pill[data-key]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const key = btn.getAttribute('data-key');
      if (key) {
        sendKey(key, btn);
      }
    });
  });

  // Number Pad Toggle
  const toggleNumpad = document.getElementById('toggle-numpad');
  const numpadGrid = document.getElementById('numpad-grid');
  toggleNumpad.addEventListener('click', () => {
    numpadGrid.classList.toggle('hidden');
    toggleNumpad.innerHTML = numpadGrid.classList.contains('hidden') 
      ? '<i class="fa-solid fa-chevron-down"></i>' 
      : '<i class="fa-solid fa-chevron-up"></i>';
  });

  // Physical Keyboard Handling
  window.addEventListener('keydown', (e) => {
    if (!chkKeyboardListener.checked) return;
    
    // Ignore if user is currently typing in an input or textarea
    const tag = document.activeElement ? document.activeElement.tagName.toLowerCase() : '';
    if (tag === 'input' || tag === 'textarea') return;

    let keycode = null;
    let selector = null;

    switch (e.key) {
      case 'ArrowUp':
        keycode = 19; selector = '.dpad-up'; break;
      case 'ArrowDown':
        keycode = 20; selector = '.dpad-down'; break;
      case 'ArrowLeft':
        keycode = 21; selector = '.dpad-left'; break;
      case 'ArrowRight':
        keycode = 22; selector = '.dpad-right'; break;
      case 'Enter':
        keycode = 66; selector = '.dpad-center'; break;
      case 'Escape':
      case 'Backspace':
        keycode = 4; selector = '.nav-btn[data-key="4"]'; break;
      case 'h':
      case 'H':
        keycode = 3; selector = '.home-btn'; break;
      case 'm':
      case 'M':
        keycode = 164; selector = '.mute-btn'; break;
      case '+':
      case '=':
        keycode = 24; selector = '.rocker-up[data-key="24"]'; break;
      case '-':
      case '_':
        keycode = 25; selector = '.rocker-down[data-key="25"]'; break;
      case ' ':
        keycode = 85; selector = '.play-pause-btn'; break;
    }

    if (keycode !== null) {
      e.preventDefault();
      const el = selector ? document.querySelector(selector) : null;
      sendKey(keycode, el);
    }
  });

  // Modals Open/Close
  statusBadge.addEventListener('click', () => modalConnect.classList.remove('hidden'));
  btnConnectModal.addEventListener('click', () => modalConnect.classList.remove('hidden'));
  closeConnectModal.addEventListener('click', () => modalConnect.classList.add('hidden'));

  btnQrModal.addEventListener('click', () => modalQr.classList.remove('hidden'));
  closeQrModal.addEventListener('click', () => modalQr.classList.add('hidden'));

  // Close modals on clicking outside backdrop
  [modalConnect, modalQr].forEach(m => {
    m.addEventListener('click', (e) => {
      if (e.target === m) m.classList.add('hidden');
    });
  });

  // Connect Button
  btnDoConnect.addEventListener('click', async () => {
    const ip = inputTvIp.value.trim();
    const port = parseInt(inputTvPort.value.trim() || '5555', 10);
    if (!ip) {
      showToast('Please enter TV IP address', 'error');
      return;
    }
    showToast(`Connecting to ${ip}:${port}...`, 'info');
    btnDoConnect.disabled = true;
    const res = await apiCall('/api/connect', 'POST', { ip, port });
    btnDoConnect.disabled = false;
    
    if (res.success) {
      showToast(`Connected to TV: ${ip}`, 'success');
      modalConnect.classList.add('hidden');
      fetchStatus();
    } else {
      showToast(res.message || 'Connection failed', 'error');
      fetchStatus();
    }
  });

  // Disconnect Button
  btnDoDisconnect.addEventListener('click', async () => {
    showToast('Disconnecting TV...', 'info');
    const res = await apiCall('/api/disconnect', 'POST', {});
    if (res.success) {
      showToast('TV Disconnected', 'info');
      fetchStatus();
    }
  });

  // TAB 2: YouTube Launcher
  const ytUrlInput = document.getElementById('yt-url-input');
  const btnPlayYt = document.getElementById('btn-play-yt');

  async function launchYouTube(urlOrId) {
    if (!urlOrId) return;
    showToast('Launching on TV...', 'info');
    const res = await apiCall('/api/launch_youtube', 'POST', { url: urlOrId });
    if (res.success) {
      showToast('Video opened on TV!', 'success');
    } else {
      showToast(res.message || 'Failed to open YouTube', 'error');
    }
  }

  btnPlayYt.addEventListener('click', () => {
    const val = ytUrlInput.value.trim();
    if (!val) {
      showToast('Please enter a YouTube link or video ID', 'error');
      return;
    }
    launchYouTube(val);
  });

  // Quick Chips YouTube
  document.querySelectorAll('.chip-btn[data-yt]').forEach(chip => {
    chip.addEventListener('click', () => {
      const ytTarget = chip.getAttribute('data-yt');
      ytUrlInput.value = ytTarget;
      launchYouTube(ytTarget);
    });
  });

  // App Cards
  document.querySelectorAll('.app-card[data-app]').forEach(card => {
    card.addEventListener('click', async () => {
      triggerHaptic();
      const appKey = card.getAttribute('data-app');
      showToast(`Opening ${appKey}...`, 'info');
      const res = await apiCall('/api/launch_app', 'POST', { app: appKey });
      if (res.success) {
        showToast(`Launched ${res.name}`, 'success');
      } else {
        showToast(res.message || 'Failed to open app', 'error');
      }
    });
  });

  // Custom App Launcher
  const customPkgInput = document.getElementById('custom-package-input');
  const btnLaunchCustomApp = document.getElementById('btn-launch-custom-app');
  btnLaunchCustomApp.addEventListener('click', async () => {
    const pkg = customPkgInput.value.trim();
    if (!pkg) {
      showToast('Please enter package name', 'error');
      return;
    }
    showToast(`Launching ${pkg}...`, 'info');
    const res = await apiCall('/api/launch_app', 'POST', { package: pkg });
    if (res.success) {
      showToast(`Launched ${pkg}`, 'success');
    } else {
      showToast(res.message || 'Failed to launch', 'error');
    }
  });

  // TAB 3: Keyboard / Text Typing
  const tvTextInput = document.getElementById('tv-text-input');
  const btnSendText = document.getElementById('btn-send-text');
  const btnSendTextEnter = document.getElementById('btn-send-text-enter');
  const btnClearTvField = document.getElementById('btn-clear-tv-field');

  async function sendTvText(pressEnter = false) {
    const text = tvTextInput.value;
    if (!text) {
      showToast('Please enter some text', 'error');
      return;
    }
    const res = await apiCall('/api/text', 'POST', { text, enter: pressEnter });
    if (res.success) {
      showToast('Text sent to TV!', 'success');
      tvTextInput.value = '';
    } else {
      showToast(res.message || 'Failed to send text', 'error');
    }
  }

  btnSendText.addEventListener('click', () => sendTvText(false));
  btnSendTextEnter.addEventListener('click', () => sendTvText(true));

  tvTextInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendTvText(true);
    }
  });

  // Clear field by sending backspaces
  btnClearTvField.addEventListener('click', async () => {
    // Send 30 backspaces
    const keys = Array(30).fill(67);
    await apiCall('/api/keyevent', 'POST', { key: keys });
    showToast('Sent clear keys', 'info');
  });

  // TAB 4: Screen & scrcpy
  const btnLaunchScrcpy = document.getElementById('btn-launch-scrcpy');
  const btnRefreshScreen = document.getElementById('btn-refresh-screen');
  const chkAutoRefresh = document.getElementById('chk-auto-refresh');
  const screenPlaceholder = document.getElementById('screen-placeholder');
  const tvScreenshotImg = document.getElementById('tv-screenshot-img');

  btnLaunchScrcpy.addEventListener('click', async () => {
    showToast('Starting scrcpy mirror window...', 'info');
    const res = await apiCall('/api/launch_scrcpy', 'POST', {});
    if (res.success) {
      showToast('scrcpy window launched on your laptop!', 'success', 4000);
    } else {
      showToast(res.message || 'Failed to launch scrcpy', 'error');
    }
  });

  async function takeScreenshot() {
    try {
      const timestamp = new Date().getTime();
      const res = await fetch(`/api/screenshot?t=${timestamp}`);
      if (res.ok) {
        const blob = await res.blob();
        tvScreenshotImg.src = URL.createObjectURL(blob);
        screenPlaceholder.classList.add('hidden');
        tvScreenshotImg.classList.remove('hidden');
      } else {
        const data = await res.json();
        showToast(data.message || 'Screenshot failed', 'error');
      }
    } catch (e) {
      showToast('Screenshot capture error', 'error');
    }
  }

  btnRefreshScreen.addEventListener('click', takeScreenshot);

  chkAutoRefresh.addEventListener('change', () => {
    if (chkAutoRefresh.checked) {
      takeScreenshot();
      autoRefreshTimer = setInterval(() => {
        if (activeTab === 'tab-screen') takeScreenshot();
      }, 3000);
    } else {
      if (autoRefreshTimer) {
        clearInterval(autoRefreshTimer);
        autoRefreshTimer = null;
      }
    }
  });

  // TAB 5: ADB Shell Terminal
  const terminalInput = document.getElementById('terminal-input');
  const btnTerminalRun = document.getElementById('btn-terminal-run');
  const terminalOutput = document.getElementById('terminal-output');
  const btnTerminalClear = document.getElementById('btn-terminal-clear');

  async function runShellCommand(cmd) {
    if (!cmd) return;
    terminalOutput.textContent += `\n$ adb shell ${cmd}\nRunning...\n`;
    terminalOutput.scrollTop = terminalOutput.scrollHeight;
    
    const res = await apiCall('/api/shell', 'POST', { command: cmd });
    if (res.success) {
      terminalOutput.textContent += res.stdout ? `${res.stdout}\n` : `[Success, return code: 0]\n`;
    } else {
      terminalOutput.textContent += `[Error: code ${res.code}]\n${res.stderr || res.stdout || 'Unknown error'}\n`;
    }
    terminalOutput.scrollTop = terminalOutput.scrollHeight;
  }

  btnTerminalRun.addEventListener('click', () => {
    const cmd = terminalInput.value.trim();
    if (cmd) {
      runShellCommand(cmd);
      terminalInput.value = '';
    }
  });

  terminalInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      btnTerminalRun.click();
    }
  });

  btnTerminalClear.addEventListener('click', () => {
    terminalOutput.textContent = 'Terminal cleared. Enter a command above...\n';
  });

  // Quick Command Chips
  document.querySelectorAll('.cmd-chip[data-cmd]').forEach(chip => {
    chip.addEventListener('click', () => {
      const cmd = chip.getAttribute('data-cmd');
      terminalInput.value = cmd;
      runShellCommand(cmd);
    });
  });
});
