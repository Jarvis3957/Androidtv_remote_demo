# 🪟 Windows Guide: Android TV Remote

This guide is designed for **Windows users with zero knowledge of code**. You don't need to know programming or type complex commands!

---

## ⚡ Option 1: Direct Download (Zero Knowledge Needed)

1. Go to the [Releases page on GitHub](https://github.com/Jarvis3957/android-tv-remote/releases).
2. Download **`AndroidTVRemote-Windows-x64.zip`**.
3. Right-click the downloaded zip and choose **Extract All**.
4. Double-click **`AndroidTVRemote.exe`**.
5. Your web browser (Edge/Chrome) will open automatically to the remote controller!
6. Keep the small window open in the background while using your remote.

---

## 🚀 Option 2: Run via Batch File (If you have Python)

1. Download or clone this repository folder to your Windows PC.
2. Open the `windows` folder.
3. Double-click **`Run_Remote.bat`**.
4. It will automatically check dependencies, download ADB, and launch your browser.

---

## 🛠️ Option 3: Compile Your Own Standalone `.exe`

If you want to build the `.exe` yourself on Windows:
```cmd
cd android-tv-remote
python windows\build_exe.py
```
Your standalone executable will be created in `dist\AndroidTVRemote.exe`.

---

## 📺 Connecting to Your Android TV

1. **On your TV:**
   - Go to **Settings** → **About** → Click **Build Number** 7 times to enable Developer Mode.
   - Go to **Settings** → **Developer Options** and turn **ON** `USB Debugging` / `Network Debugging`.
   - Go to **Settings** → **Network** and look at your TV's **IP Address** (e.g. `192.168.1.15`).
2. **On the Web Remote:**
   - Click the Wi-Fi icon in the top right corner.
   - Type your TV's IP address and click **Connect**.
   - **Look at your TV screen** and click **"Always allow from this computer"** → **OK**.
3. Done! You can now control your TV from your PC or scan the QR code to control it from your phone!
