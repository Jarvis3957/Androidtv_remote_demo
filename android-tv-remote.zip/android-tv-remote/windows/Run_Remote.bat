@echo off
title Android TV Remote
color 0b
echo ============================================================
echo         Android TV Web Remote Launcher (Windows)
echo ============================================================
echo.

cd /d "%~dp0\.."

:: Check if Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [X] Python was not found on your system!
    echo.
    echo Please install Python 3 from https://www.python.org/downloads/
    echo (Make sure to check "Add Python to PATH" during installation)
    echo.
    pause
    exit /b 1
)

:: Install requirements silently if missing
echo Checking dependencies...
python -c "import flask, qrcode, PIL" >nul 2>&1
if %errorlevel% neq 0 (
    echo Installing required packages (one-time setup)...
    python -m pip install --upgrade pip >nul 2>&1
    python -m pip install -r requirements.txt
)

echo Starting Android TV Remote...
echo Your browser will open automatically in a moment.
echo Keep this window open while using the remote.
echo.

python app.py
pause
