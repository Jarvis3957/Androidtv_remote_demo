"""
Build script to compile Android TV Remote into a standalone Windows .exe
Run on Windows: python windows/build_exe.py
"""
import os
import sys
import shutil
import urllib.request
import zipfile
import subprocess

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WINDOWS_DIR = os.path.join(ROOT_DIR, 'windows')
TOOLS_DIR = os.path.join(ROOT_DIR, 'platform-tools')

def install_pyinstaller():
    print("[1/4] Checking and installing PyInstaller...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "pip"])
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", os.path.join(ROOT_DIR, "requirements.txt")])
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pyinstaller"])

def download_windows_adb():
    print("[2/4] Downloading official Google Android ADB for Windows...")
    if os.path.exists(TOOLS_DIR) and os.path.isfile(os.path.join(TOOLS_DIR, 'adb.exe')):
        print("  -> ADB already present, skipping download.")
        return

    url = "https://dl.google.com/android/repository/platform-tools-latest-windows.zip"
    zip_path = os.path.join(ROOT_DIR, "platform-tools-windows.zip")
    
    urllib.request.urlretrieve(url, zip_path)
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(ROOT_DIR)
        
    if os.path.exists(zip_path):
        os.remove(zip_path)
    print("  -> Downloaded and extracted platform-tools successfully.")

def build_exe():
    print("[3/4] Compiling standalone Windows executable with PyInstaller...")
    os.chdir(ROOT_DIR)
    
    # Path delimiter for PyInstaller --add-data: ';' on Windows, ':' on Unix
    sep = ';' if os.name == 'nt' else ':'
    
    cmd = [
        sys.executable, "-m", "PyInstaller",
        "--name", "AndroidTVRemote",
        "--noconfirm",
        "--clean",
        "--onefile",
        f"--add-data=templates{sep}templates",
        f"--add-data=static{sep}static",
    ]
    
    if os.path.exists(TOOLS_DIR):
        cmd.append(f"--add-data=platform-tools{sep}platform-tools")
        
    cmd.append("app.py")
    
    subprocess.check_call(cmd)
    print("\n[4/4] Build complete! Executable is located in:")
    dist_exe = os.path.join(ROOT_DIR, "dist", "AndroidTVRemote.exe")
    print(f"       -> {dist_exe}\n")

if __name__ == '__main__':
    install_pyinstaller()
    download_windows_adb()
    build_exe()
