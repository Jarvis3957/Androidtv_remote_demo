#!/usr/bin/env bash
# Android TV Web Remote Launcher Script

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
cd "$DIR"

PORT="${1:-5000}"

# Check virtual environment
if [ ! -d "$DIR/venv" ]; then
    echo "Creating Python virtual environment..."
    python3 -m venv "$DIR/venv"
    "$DIR/venv/bin/pip" install --upgrade pip
    "$DIR/venv/bin/pip" install flask qrcode pillow
fi

# Ensure adb is accessible
if ! command -v adb &> /dev/null; then
    echo "Warning: adb is not found in PATH. Install with: sudo apt install android-tools-adb -y"
fi

echo "=========================================================="
echo "    📺 Launching Android TV Web Remote on port $PORT"
echo "=========================================================="

export PORT="$PORT"
exec "$DIR/venv/bin/python3" "$DIR/app.py"
