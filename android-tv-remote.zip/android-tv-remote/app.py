import os
import sys
import re
import json
import socket
import subprocess
import shutil
import io
import threading
import time
import webbrowser
import urllib.request
import zipfile
from flask import Flask, render_template, request, jsonify, send_file, Response
import qrcode

# Resolve bundle and application paths (supports PyInstaller .exe)
if getattr(sys, 'frozen', False):
    BUNDLE_DIR = sys._MEIPASS
    APP_DIR = os.path.dirname(sys.executable)
else:
    BUNDLE_DIR = os.path.dirname(os.path.abspath(__file__))
    APP_DIR = BUNDLE_DIR

app = Flask(
    __name__,
    template_folder=os.path.join(BUNDLE_DIR, 'templates'),
    static_folder=os.path.join(BUNDLE_DIR, 'static')
)

CONFIG_FILE = os.path.join(APP_DIR, 'config.json')

def load_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r') as f:
                return json.load(f)
        except Exception:
            pass
    return {"last_ip": "192.168.20.24", "last_port": 5555, "active_device": None}

def save_config(cfg):
    try:
        with open(CONFIG_FILE, 'w') as f:
            json.dump(cfg, f, indent=2)
    except Exception as e:
        print(f"Error saving config: {e}")

config = load_config()

def ensure_adb():
    """Ensure ADB is available. On Windows, auto-downloads platform-tools if missing."""
    adb_bin = get_adb_binary()
    if adb_bin and (shutil.which(adb_bin) or os.path.isfile(adb_bin)):
        return adb_bin
    
    if os.name == 'nt':
        print("\n[!] ADB not found. Auto-downloading official Android Platform Tools for Windows...")
        tools_dir = os.path.join(APP_DIR, 'platform-tools')
        zip_path = os.path.join(APP_DIR, 'platform-tools-windows.zip')
        url = "https://dl.google.com/android/repository/platform-tools-latest-windows.zip"
        try:
            urllib.request.urlretrieve(url, zip_path)
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(APP_DIR)
            if os.path.exists(zip_path):
                os.remove(zip_path)
            print("[+] Android Platform Tools installed successfully!\n")
            return get_adb_binary()
        except Exception as e:
            print(f"[-] Could not auto-download ADB: {e}")
            
    return 'adb'

def get_adb_binary():
    """Find adb binary path across Windows/Linux/bundled paths."""
    candidates = [
        os.path.join(APP_DIR, 'platform-tools', 'adb.exe'),
        os.path.join(APP_DIR, 'adb.exe'),
        os.path.join(BUNDLE_DIR, 'platform-tools', 'adb.exe'),
        os.path.join(BUNDLE_DIR, 'adb.exe'),
        os.path.join(APP_DIR, 'platform-tools', 'adb'),
        os.path.join(BUNDLE_DIR, 'platform-tools', 'adb'),
    ]
    for path in candidates:
        if os.path.isfile(path):
            return path
            
    which = shutil.which('adb.exe' if os.name == 'nt' else 'adb')
    if which:
        return which
    return 'adb'

def get_primary_ip():
    """Find the best local LAN IP address of this machine."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.1)
        s.connect(('8.8.8.8', 1))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        pass
    try:
        out = subprocess.run(['hostname', '-I'], capture_output=True, text=True, timeout=2).stdout.split()
        for ip in out:
            if ':' not in ip and not ip.startswith('127.'):
                return ip
    except Exception:
        pass
    return "127.0.0.1"

def run_adb(args, timeout=10, device=None):
    """Run an adb command with optional specific device target."""
    cmd = [get_adb_binary()]
    if device:
        cmd.extend(['-s', device])
    cmd.extend(args)
    
    # Hide black console window popups on Windows
    creationflags = 0
    if os.name == 'nt':
        creationflags = subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0x08000000

    try:
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, creationflags=creationflags)
        return {
            "success": res.returncode == 0,
            "stdout": res.stdout.strip(),
            "stderr": res.stderr.strip(),
            "code": res.returncode
        }
    except subprocess.TimeoutExpired:
        return {"success": False, "stdout": "", "stderr": "Command timed out", "code": -1}
    except Exception as e:
        return {"success": False, "stdout": "", "stderr": str(e), "code": -1}

def get_connected_devices():
    """List devices recognized by adb."""
    res = run_adb(['devices'])
    devices = []
    if res["success"]:
        lines = res["stdout"].split('\n')
        for line in lines[1:]:
            parts = line.strip().split()
            if len(parts) >= 2:
                devices.append({
                    "id": parts[0],
                    "state": parts[1]
                })
    return devices

def get_active_device():
    """Return active device if connected, or auto-select one."""
    devices = get_connected_devices()
    valid_devices = [d["id"] for d in devices if d["state"] == "device"]
    
    saved_active = config.get("active_device")
    if saved_active and saved_active in valid_devices:
        return saved_active
    
    if valid_devices:
        config["active_device"] = valid_devices[0]
        save_config(config)
        return valid_devices[0]
    
    return None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/status', methods=['GET'])
def api_status():
    devices = get_connected_devices()
    active = get_active_device()
    ip = get_primary_ip()
    port = request.host.split(':')[1] if ':' in request.host else '5000'
    server_url = f"http://{ip}:{port}"
    
    device_model = None
    if active:
        model_res = run_adb(['shell', 'getprop', 'ro.product.model'], device=active, timeout=2)
        if model_res["success"] and model_res["stdout"]:
            device_model = model_res["stdout"]
        else:
            brand_res = run_adb(['shell', 'getprop', 'ro.product.brand'], device=active, timeout=2)
            if brand_res["success"] and brand_res["stdout"]:
                device_model = brand_res["stdout"].capitalize() + " TV"

    return jsonify({
        "status": "connected" if active else ("unauthorized" if any(d["state"] == "unauthorized" for d in devices) else "disconnected"),
        "devices": devices,
        "active_device": active,
        "device_model": device_model,
        "last_ip": config.get("last_ip", ""),
        "last_port": config.get("last_port", 5555),
        "server_url": server_url,
        "server_ip": ip
    })

@app.route('/api/connect', methods=['POST'])
def api_connect():
    data = request.get_json() or {}
    tv_ip = data.get("ip", "").strip()
    tv_port = data.get("port", 5555)
    
    if not tv_ip:
        return jsonify({"success": False, "message": "IP address is required"}), 400
    
    target = f"{tv_ip}:{tv_port}"
    res = run_adb(['connect', target], timeout=8)
    
    config["last_ip"] = tv_ip
    config["last_port"] = tv_port
    if "connected to" in res["stdout"].lower() or "already connected" in res["stdout"].lower():
        config["active_device"] = target
        save_config(config)
        return jsonify({
            "success": True,
            "message": res["stdout"],
            "target": target
        })
    else:
        save_config(config)
        return jsonify({
            "success": False,
            "message": res["stdout"] or res["stderr"] or "Could not connect to TV",
            "target": target
        }), 400

@app.route('/api/disconnect', methods=['POST'])
def api_disconnect():
    data = request.get_json() or {}
    target = data.get("device") or get_active_device()
    if target:
        res = run_adb(['disconnect', target])
        if config.get("active_device") == target:
            config["active_device"] = None
            save_config(config)
        return jsonify({"success": True, "message": res["stdout"] or "Disconnected"})
    else:
        run_adb(['disconnect'])
        config["active_device"] = None
        save_config(config)
        return jsonify({"success": True, "message": "All devices disconnected"})

@app.route('/api/pair', methods=['POST'])
def api_pair():
    data = request.get_json() or {}
    ip = data.get("ip", "").strip()
    port = data.get("port")
    code = data.get("code", "").strip()
    if not ip or not port or not code:
        return jsonify({"success": False, "message": "IP, pairing port, and 6-digit code are required"}), 400
    res = run_adb(['pair', f"{ip}:{port}", code], timeout=10)
    return jsonify({
        "success": res["success"],
        "stdout": res["stdout"],
        "stderr": res["stderr"]
    })

@app.route('/api/set_active', methods=['POST'])
def api_set_active():
    data = request.get_json() or {}
    device_id = data.get("device")
    if device_id:
        config["active_device"] = device_id
        save_config(config)
        return jsonify({"success": True, "active_device": device_id})
    return jsonify({"success": False, "message": "No device provided"}), 400

@app.route('/api/keyevent', methods=['POST'])
def api_keyevent():
    device = get_active_device()
    if not device:
        return jsonify({"success": False, "message": "No TV connected"}), 400
    
    data = request.get_json() or {}
    key = data.get("key")
    if key is None:
        return jsonify({"success": False, "message": "Keycode is required"}), 400
    
    keys = key if isinstance(key, list) else [key]
    outputs = []
    for k in keys:
        res = run_adb(['shell', 'input', 'keyevent', str(k)], device=device, timeout=3)
        outputs.append(res)
        
    return jsonify({"success": True, "results": outputs})

@app.route('/api/text', methods=['POST'])
def api_text():
    device = get_active_device()
    if not device:
        return jsonify({"success": False, "message": "No TV connected"}), 400
    
    data = request.get_json() or {}
    text = data.get("text", "")
    if not text:
        return jsonify({"success": False, "message": "No text provided"}), 400
    
    escaped = ""
    for ch in text:
        if ch == ' ':
            escaped += '%s'
        elif ch in ['"', "'", '\\', '$', '`', '&', ';', '|', '<', '>', '(', ')']:
            escaped += '\\' + ch
        else:
            escaped += ch
            
    res = run_adb(['shell', 'input', 'text', escaped], device=device, timeout=5)
    
    if data.get("enter", False):
        run_adb(['shell', 'input', 'keyevent', '66'], device=device, timeout=2)
        
    return jsonify({
        "success": res["success"],
        "stdout": res["stdout"],
        "stderr": res["stderr"]
    })

def extract_youtube_video_id(url_or_id):
    url_or_id = url_or_id.strip()
    if re.match(r'^[a-zA-Z0-9_-]{11}$', url_or_id):
        return url_or_id
    
    patterns = [
        r'(?:v=|\/v\/|youtu\.be\/|\/embed\/|\/watch\?v=|\/shorts\/)([a-zA-Z0-9_-]{11})',
        r'vnd\.youtube:\/\/.*?watch\?v=([a-zA-Z0-9_-]{11})',
        r'vnd\.youtube:\/\/([a-zA-Z0-9_-]{11})'
    ]
    for p in patterns:
        m = re.search(p, url_or_id)
        if m:
            return m.group(1)
    return None

@app.route('/api/launch_youtube', methods=['POST'])
def api_launch_youtube():
    device = get_active_device()
    if not device:
        return jsonify({"success": False, "message": "No TV connected"}), 400
    
    data = request.get_json() or {}
    url = data.get("url", "").strip()
    query = data.get("query", "").strip()
    
    if url:
        vid_id = extract_youtube_video_id(url)
        if vid_id:
            intent_uri = f"vnd.youtube://www.youtube.com/watch?v={vid_id}"
        elif url.startswith("vnd.youtube://") or url.startswith("http"):
            intent_uri = url
        else:
            intent_uri = f"vnd.youtube://www.youtube.com/watch?v={url}"
        
        res = run_adb(['shell', 'am', 'start', '-a', 'android.intent.action.VIEW', '-d', intent_uri], device=device, timeout=5)
    elif query:
        intent_uri = f"vnd.youtube://www.youtube.com/results?search_query={query}"
        res = run_adb(['shell', 'am', 'start', '-a', 'android.intent.action.VIEW', '-d', intent_uri], device=device, timeout=5)
    else:
        res = run_adb(['shell', 'am', 'start', '-a', 'android.intent.action.VIEW', '-d', 'vnd.youtube://'], device=device, timeout=5)
        
    return jsonify({
        "success": res["success"],
        "stdout": res["stdout"],
        "stderr": res["stderr"]
    })

APPS_MAP = {
    "youtube": {
        "name": "YouTube",
        "action": ["shell", "am", "start", "-a", "android.intent.action.VIEW", "-d", "vnd.youtube://"]
    },
    "netflix": {
        "name": "Netflix",
        "action": ["shell", "am", "start", "-n", "com.netflix.ninja/.MainActivity"]
    },
    "prime": {
        "name": "Amazon Prime Video",
        "action": ["shell", "am", "start", "-n", "com.amazon.amazonvideo.livingroom/com.amazon.ignition.IgnitionActivity"]
    },
    "hotstar": {
        "name": "Disney+ Hotstar",
        "action": ["shell", "monkey", "-p", "in.startv.hotstar", "-c", "android.intent.category.LAUNCHER", "1"]
    },
    "jiocinema": {
        "name": "JioCinema",
        "action": ["shell", "monkey", "-p", "com.jio.media.ondemand", "-c", "android.intent.category.LAUNCHER", "1"]
    },
    "spotify": {
        "name": "Spotify",
        "action": ["shell", "am", "start", "-n", "com.spotify.tv.android/.MainActivity"]
    },
    "smarttube": {
        "name": "SmartTube",
        "action": ["shell", "am", "start", "-n", "com.teamsmart.videomanager.tv/.ui.MainActivity"]
    },
    "vlc": {
        "name": "VLC",
        "action": ["shell", "am", "start", "-n", "org.videolan.vlc/.gui.tv.MainTvActivity"]
    },
    "settings": {
        "name": "Android TV Settings",
        "action": ["shell", "am", "start", "-a", "android.settings.SETTINGS"]
    },
    "wifi": {
        "name": "Wi-Fi Settings",
        "action": ["shell", "am", "start", "-a", "android.settings.WIFI_SETTINGS"]
    },
    "all_apps": {
        "name": "App Drawer",
        "action": ["shell", "input", "keyevent", "284"]
    }
}

@app.route('/api/launch_app', methods=['POST'])
def api_launch_app():
    device = get_active_device()
    if not device:
        return jsonify({"success": False, "message": "No TV connected"}), 400
    
    data = request.get_json() or {}
    app_key = data.get("app")
    custom_pkg = data.get("package", "").strip()
    
    if app_key and app_key in APPS_MAP:
        cmd = APPS_MAP[app_key]["action"]
        res = run_adb(cmd, device=device, timeout=5)
        return jsonify({
            "success": res["success"],
            "stdout": res["stdout"],
            "stderr": res["stderr"],
            "name": APPS_MAP[app_key]["name"]
        })
    elif custom_pkg:
        cmd = ["shell", "monkey", "-p", custom_pkg, "-c", "android.intent.category.LAUNCHER", "1"]
        res = run_adb(cmd, device=device, timeout=5)
        return jsonify({
            "success": res["success"],
            "stdout": res["stdout"],
            "stderr": res["stderr"],
            "name": custom_pkg
        })
    else:
        return jsonify({"success": False, "message": "Invalid app or package"}), 400

@app.route('/api/shell', methods=['POST'])
def api_shell():
    device = get_active_device()
    if not device:
        return jsonify({"success": False, "message": "No TV connected"}), 400
    
    data = request.get_json() or {}
    command = data.get("command", "").strip()
    if not command:
        return jsonify({"success": False, "message": "Command is required"}), 400
    
    res = run_adb(['shell', command], device=device, timeout=10)
    return jsonify(res)

@app.route('/api/screenshot', methods=['GET'])
def api_screenshot():
    device = get_active_device()
    if not device:
        return jsonify({"success": False, "message": "No TV connected"}), 400
    
    cmd = [get_adb_binary(), '-s', device, 'exec-out', 'screencap', '-p']
    creationflags = 0
    if os.name == 'nt':
        creationflags = subprocess.CREATE_NO_WINDOW if hasattr(subprocess, 'CREATE_NO_WINDOW') else 0x08000000

    try:
        proc = subprocess.run(cmd, capture_output=True, timeout=8, creationflags=creationflags)
        if proc.returncode == 0 and len(proc.stdout) > 100:
            return Response(
                proc.stdout,
                mimetype='image/png',
                headers={'Cache-Control': 'no-cache, no-store, must-revalidate'}
            )
        else:
            return jsonify({"success": False, "message": proc.stderr.decode('utf-8', errors='ignore') or "Failed to grab screenshot"}), 500
    except subprocess.TimeoutExpired:
        return jsonify({"success": False, "message": "Screenshot capture timed out"}), 504
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/launch_scrcpy', methods=['POST'])
def api_launch_scrcpy():
    device = get_active_device()
    if not device:
        return jsonify({"success": False, "message": "No TV connected"}), 400
    
    try:
        env = os.environ.copy()
        if os.name != 'nt' and 'DISPLAY' not in env and 'WAYLAND_DISPLAY' not in env:
            env['DISPLAY'] = ':0'
            
        scrcpy_bin = shutil.which('scrcpy.exe' if os.name == 'nt' else 'scrcpy') or 'scrcpy'
        cmd = [scrcpy_bin, '-s', device, '--window-title', f"Android TV ({device})", '--stay-awake']
        subprocess.Popen(cmd, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return jsonify({"success": True, "message": f"scrcpy launched for {device}"})
    except Exception as e:
        return jsonify({"success": False, "message": f"Failed to launch scrcpy: {str(e)}"}), 500

@app.route('/api/qr')
def api_qr():
    ip = get_primary_ip()
    port = request.host.split(':')[1] if ':' in request.host else '5000'
    url = f"http://{ip}:{port}"
    
    qr = qrcode.QRCode(box_size=8, border=2)
    qr.add_data(url)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    
    buf = io.BytesIO()
    img.save(buf, format='PNG')
    buf.seek(0)
    return send_file(buf, mimetype='image/png')

def auto_open_browser(port):
    time.sleep(1.2)
    try:
        webbrowser.open(f"http://localhost:{port}")
    except Exception:
        pass

if __name__ == '__main__':
    ensure_adb()
    port = int(os.environ.get('PORT', 5000))
    ip = get_primary_ip()
    print("=" * 60)
    print("   📺 ANDROID TV WEB REMOTE SERVER")
    print("=" * 60)
    print(f" Local Web URL:     http://localhost:{port}")
    print(f" Wi-Fi / Phone URL: http://{ip}:{port}")
    print("=" * 60)
    
    # Auto open browser for non-tech users
    threading.Thread(target=auto_open_browser, args=(port,), daemon=True).start()
    
    app.run(host='0.0.0.0', port=port, debug=False)
