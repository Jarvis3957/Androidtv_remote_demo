# 📺 Android TV Web Remote & Screen Control

A modern, responsive web application that turns any browser (laptop, tablet, or smartphone) into a powerful remote control and screen mirroring hub for your Android TV / Google TV (Mi / Redmi TV, Sony Bravia, OnePlus TV, Realme, TCL, etc.) via ADB.

---

## 🪟 Windows Users (Zero Knowledge of Code)

If you are on Windows and don't want to install Python, ADB, or type any commands:
1. Go to **[Releases](https://github.com/Jarvis3957/android-tv-remote/releases)** and download **`AndroidTVRemote-Windows-x64.zip`**.
2. Unzip it and double-click **`AndroidTVRemote.exe`**.
3. Your browser will open automatically! Everything (including Google ADB) is pre-bundled.
*(See detailed [Windows Guide](windows/README.md) for screenshots and instructions).*

---

## 🚀 Linux / Mac Quick Start

### 1. Start the Remote Server
From your terminal:
```bash
cd /home/rahul/android-tv-remote
./start.sh
```

The server will output:
```text
============================================================
   📺 ANDROID TV WEB REMOTE SERVER
============================================================
 Local Web URL:     http://localhost:5000
 Wi-Fi / Phone URL: http://192.168.29.137:5000
============================================================
```

### 2. Open the Remote
- **On Laptop:** Open [http://localhost:5000](http://localhost:5000)
- **On Smartphone:** Connect your phone to the same Wi-Fi and open `http://192.168.29.137:5000` (or click the **QR Code** button in the top right to scan with your phone camera!).

---

## 🛠️ Android TV Setup (Prerequisites)

### Step 1: Turn ON Developer Options on Android TV
1. On your TV, go to **Settings** (⚙️) → **Device Preferences** (or **System**) → **About**.
2. Scroll down to **Android TV OS Build** (or **Build Number**).
3. Click the **OK** button on your remote **7 times** until you see:
   > *"You are now a developer!"*

### Step 2: Enable Network & USB Debugging
1. Go back to **Settings** → **Device Preferences** → **Developer Options**.
2. Turn **ON**:
   - **USB Debugging** (or **Network Debugging**)
   - **ADB Debugging**

### Step 3: Find Your TV's IP Address
1. Go to **Settings** → **Network & Internet** → Select your connected Wi-Fi network.
2. Note down the **IP address** (e.g. `192.168.20.24` or `192.168.29.xxx`).
   > *Note: Laptop and TV must be connected to the same Wi-Fi router.*

### Step 4: Authorize Laptop on TV (First Time Only)
1. Open the Web Remote at [http://localhost:5000](http://localhost:5000).
2. Click **Connection Settings** (Wi-Fi icon top right or status badge).
3. Enter your TV's IP address and click **Connect**.
4. **Look at your TV screen!** A dialog will pop up:
   > *"Allow USB debugging from this computer?"*
5. Check the box **"Always allow from this computer"** and click **OK** with your physical TV remote.
6. The status pill on the web remote will turn **Green (Connected)**!

---

## ✨ Features & Capabilities

### 🎮 1. Ergonomic Smart TV Remote
- **Circular D-Pad:** Up, Down, Left, Right, and Center **OK** button.
- **Navigation Row:** Back, Home (distinct blue glow), Recent Apps / Menu.
- **Power & Mute:** Toggle power, mute audio (Keyevent 164), TV source input.
- **Volume & Channel Rockers:** Dedicated Vol +/- and Ch +/- toggles.
- **Media Controls:** Play/Pause (Keyevent 85), Fast-Forward, Rewind, Next, Previous.
- **Collapsible Number Pad:** Direct 0-9 channel keypad.
- **Haptic Vibration:** Tactile vibration on touchscreens.

### ⌨️ 2. Laptop Keyboard Shortcuts
When using your laptop browser, you can control the TV using your physical keyboard without clicking:
| Key | Remote Action | ADB Keycode |
|---|---|---|
| `↑` `↓` `←` `→` | D-Pad Navigation | 19, 20, 21, 22 |
| `Enter` | OK / Select | 66 / 23 |
| `Esc` or `Backspace` | Back | 4 |
| `H` or `h` | Home Screen | 3 |
| `M` or `m` | Mute | 164 |
| `+` / `-` | Volume Up / Down | 24 / 25 |
| `Space` | Play / Pause | 85 |

### 🎬 3. Direct YouTube Video Player
- Open YouTube app instantly.
- Paste any YouTube link (e.g., `https://www.youtube.com/watch?v=FZLadzn5i6Q` or `vnd.youtube://...`) or Video ID (`FZLadzn5i6Q`) to play directly on TV!
- One-click quick chip for *Rasha ❤️*.

### 📱 4. Quick App Launcher
One-click shortcuts for popular streaming services and utilities:
- **YouTube** (`vnd.youtube://`)
- **Netflix** (`com.netflix.ninja`)
- **Amazon Prime Video** (`com.amazon.amazonvideo.livingroom`)
- **Disney+ Hotstar** (`in.startv.hotstar`)
- **JioCinema** (`com.jio.media.ondemand`)
- **Spotify** (`com.spotify.tv.android`)
- **SmartTube** (`com.teamsmart.videomanager.tv`)
- **VLC** (`org.videolan.vlc`)
- **Android TV Settings** (`android.settings.SETTINGS`)
- **Wi-Fi Settings** (`android.settings.WIFI_SETTINGS`)
- **Custom Android Package:** Launch any app by package name.

### ✍️ 5. Smart Keyboard / Text Input
- Type search queries, Wi-Fi passwords, or URLs on your laptop/phone keyboard and send directly to the active text field on your TV screen!
- Automatically escapes spaces (`%s`) and shell characters.
- Fast Backspace & "Clear Field" macros.

### 🖥️ 6. Screen Mirroring & Scrcpy
- **One-Click Scrcpy:** Launches `scrcpy` on your Ubuntu laptop desktop for ultra-low latency audio/video screen mirroring and direct mouse/keyboard control.
- **In-Browser TV Screen Preview:** Take high-resolution snapshots of your TV screen right in the webpage (`adb exec-out screencap -p`), with optional **Auto-Refresh** every 3 seconds!

### 💻 7. Built-in ADB Shell Terminal
- Run any shell command directly from the web interface (e.g., `dumpsys audio`, `getprop ro.product.model`, `pm list packages -3`).
- Quick-command chips for device status and properties.

---

## 📋 Common ADB Commands Cheat Sheet

```bash
# Connect to TV
adb connect <TV_IP>:5555

# Check connection status
adb devices

# Send Keyevents
adb shell input keyevent 3     # Home
adb shell input keyevent 4     # Back
adb shell input keyevent 26    # Power Toggle
adb shell input keyevent 66    # Enter / OK
adb shell input keyevent 24    # Volume Up
adb shell input keyevent 25    # Volume Down
adb shell input keyevent 164   # Mute
adb shell input keyevent 85    # Play / Pause

# Launch YouTube
adb shell am start -a android.intent.action.VIEW -d "vnd.youtube://"

# Launch Specific YouTube Video (Rasha ❤️)
adb shell am start -a android.intent.action.VIEW -d "vnd.youtube://www.youtube.com/watch?v=FZLadzn5i6Q"

# Project TV to Laptop screen with scrcpy
scrcpy -s <TV_IP>:5555 --stay-awake
```

---

## ❓ Troubleshooting

1. **Status says "Auth Needed" or "unauthorized":**
   - Look at your TV screen. An ADB authorization prompt is waiting for confirmation.
   - Check "Always allow from this computer" and click OK with your TV remote.
2. **TV doesn't connect ("Connection refused"):**
   - Make sure Developer Options & USB / Network debugging are enabled on your TV.
   - Verify TV and Laptop are on the exact same Wi-Fi network (check IP subnets e.g. `192.168.29.xxx`).
   - Try toggling USB Debugging OFF and ON in TV Developer Options.
3. **Cannot open webpage on phone:**
   - Make sure your phone Wi-Fi is connected to the same router as your laptop.
   - Verify your laptop's local IP address (run `hostname -I`).
   - Ensure Ubuntu firewall isn't blocking port 5000 (`sudo ufw allow 5000/tcp`).
